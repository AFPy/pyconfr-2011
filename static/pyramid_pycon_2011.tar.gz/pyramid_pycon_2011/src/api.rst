Construire une api
===================

Plusieurs rendu par vue::

    @view_config(route_name='home', accept='application/json', renderer='json')
    @view_config(route_name='home', accept='text/xml', renderer='xml_template.pt')
    @view_config(route_name='home', renderer='template.pt')
    def view(request):
        return {}



Ajout de moteur de rendu::

    from pyquery import PyQuery

    def string_response_adapter(pq):
        response = Response(str(pq))
        response.content_type = 'text/xml'
        return response

    config = Configurator()
    config.add_response_adapter(string_response_adapter, PyQuery)

----

Helpers
==============

pyramid_handler::

  class MyView(object):

  def __init__(self, request):
      self.request = request

  @action(renderer='json')
  def edit(self):
      return {}


  config.add_handler('hello', '/hello/{action}', handler=MyView)

----
  
Helpers xmlrpc
==============

pyramid_xmlrpc::

  @xmlrpc_view
  def view(context, name):
      return 'Hello %s' % name

