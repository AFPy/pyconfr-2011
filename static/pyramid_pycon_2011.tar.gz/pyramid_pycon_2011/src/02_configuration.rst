Configuration par décorateurs
======================================

Avec une fonction::

    @view_config(route_name='home')
    def view(request):
        return Response()

Avec une classe::

    class View(object):

        @view_config(route_name='home')
        def view(request):
            return Response()

----


Extension du configurator
==========================

Permets d'étendre le configurateur::

  def my_directive(config, **kw):
      # do stuff

  config.add_directive('my_directive', my_directive)
  config.my_directive()

----

Inclusion de package
=====================

Permet d'inclure la configuration d'un package::

    # mypackage/__init__py
    def includeme(config):
        # do stuff

    # application
    config.include('mypackage')

