Dispatch
===========

Routing

- Association route / vue

Traversing:

- Object racine

- Notion de tree grace à __getitem__

- Vue associé à un contexte

On peut combiner routing et traversing

----

Vues
========

Vue basée sur des fonctions::

  def view(request):
      return Response()

Ou des classes::

  class View(object):

      def __init__(self, request):
          self.request = request

      def view(self):
          return Response()

      def __call__(self):
          return Response()

----

Authentification / Authorisation
=================================

Authentification:

- Basic

- Cookie

- pyramid_who

Authorisation:

- view

- context

Les ACLs sont souple. La stratégie est libre 

----

Événements
===========

NewRequest

BeforeRender



