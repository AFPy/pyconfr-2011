Outils
=======

- paster templates (Akhet/SQLAlchemy/Formalchemy..)

- debug toolbar (inspirée de Django)

- WebError / pyramid_exclog


