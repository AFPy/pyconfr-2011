WSGI
=====

- Basé sur WebOb:

  - Request

  - Response

- Application::

    from pyramid.config import Configurator
    
    def view(request):
        return Response()

    def make_application(global_config, **settings):
        config = Configurator(settings=settings)
        config.add_route('home', '/')
        config.add_view(view, route_name='home')
        return config.make_wsgi_app()

