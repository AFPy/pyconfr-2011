Pourquoi et comment choisir Pyramid
=====================================

.. raw:: html

  <div style="font-size:1.5em">

  <h2 style="text-align:center;font-size:1.5em">
  Gael Pasgrimaud
  </h2>

  <center>
  @gawel_
  </center>
  <center>
  @bearstech
  </center>

  </div>

----

Historique
===========

Pylons

Zope inspire repoze.bfg

Fusion repoze.bfg/Pylons


